CREATE SMALLFILE TABLESPACE "USERS" LOGGING DATAFILE '/cpc_data01/CPCEX/users01.dbf' SIZE 5M REUSE AUTOEXTEND OFF;
ALTER DATABASE DEFAULT TABLESPACE "USERS";

create tablespace CPC_DATA datafile '/cpc_data01/CPCEX/cpc_dat01.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat02.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat03.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat04.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat05.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat06.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat07.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat08.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat09.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat10.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat11.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat12.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat13.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat14.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat15.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat16.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat17.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat18.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat19.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat20.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat21.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat22.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat23.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat24.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat25.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat26.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat27.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat28.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat29.dbf' size 30G,
'/cpc_data01/CPCEX/cpc_dat30.dbf' size 30G,
'/cpc_data02/CPCEX/cpc_dat31.dbf' size 30G,
'/cpc_data02/CPCEX/cpc_dat32.dbf' size 30G,
'/cpc_data02/CPCEX/cpc_dat33.dbf' size 30G,
'/cpc_data02/CPCEX/cpc_dat34.dbf' size 30G,
'/cpc_data02/CPCEX/cpc_dat35.dbf' size 30G,
'/cpc_data02/CPCEX/cpc_dat36.dbf' size 30G,
'/cpc_data02/CPCEX/cpc_dat37.dbf' size 30G,
'/cpc_data02/CPCEX/cpc_dat38.dbf' size 30G;

create tablespace CPC_INDX datafile '/cpc_data02/CPCEX/cpc_idx01.dbf' size 30G,
'/cpc_data02/CPCEX/cpc_idx02.dbf' size 30G;

create tablespace BLOBS datafile '/cpc_data02/CPCEX/blobs01.dbf' size 20G;

create tablespace IDX datafile '/cpc_data02/CPCEX/idx01.dbf' size 30G,
'/cpc_data02/CPCEX/idx02.dbf' size 30G,
'/cpc_data02/CPCEX/idx03.dbf' size 30G,
'/cpc_data02/CPCEX/idx04.dbf' size 30G,
'/cpc_data02/CPCEX/idx05.dbf' size 30G,
'/cpc_data02/CPCEX/idx06.dbf' size 30G,
'/cpc_data02/CPCEX/idx07.dbf' size 20G;

