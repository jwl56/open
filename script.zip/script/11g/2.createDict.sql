# 2013.01.23 Create by anjae83
# Execute create dictionary query
@?/rdbms/admin/catalog.sql
@?/rdbms/admin/catblock.sql
@?/rdbms/admin/catproc.sql
@?/rdbms/admin/catoctk.sql

alter user system identified by "!wjswk!2#4";
conn system/!wjswk!2#4;
@?/sqlplus/admin/pupbld.sql
@?/sqlplus/admin/help/hlpbld.sql helpus.sql

exit
