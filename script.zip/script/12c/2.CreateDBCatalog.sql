SET VERIFY OFF
set echo on
spool /oracle/script/B2BI/log/CreateDBCatalog.sql append
@/oracle/product/rdbms/admin/catalog.sql;
@/oracle/product/rdbms/admin/catproc.sql;
@/oracle/product/rdbms/admin/catoctk.sql;
@/oracle/product/rdbms/admin/catblock.sql;

alter user system identified by "!wjswk!2#4";
conn system/!wjswk!2#4;
@/oracle/product/sqlplus/admin/pupbld.sql;
@/oracle/product/sqlplus/admin/help/hlpbld.sql helpus.sql;
spool off

--spool /oracle/postDBCreation.log append
--create or replace directory ORACLE_HOME as '/oracle/product';
--create or replace directory ORACLE_BASE as '/oracle';
--grant sysdg to sysdg;
--grant sysbackup to sysbackup;
--grant syskm to syskm;
