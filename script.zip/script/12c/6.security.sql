@?/rdbms/admin/utlpwdmg.sql

alter profile DEFAULT limit password_life_time 90;
alter profile DEFAULT limit password_reuse_max 1;
alter profile DEFAULT limit password_reuse_time 180;
alter profile DEFAULT limit failed_login_attempts 5;

CREATE PROFILE "CI_PROFILE"
    LIMIT
         FAILED_LOGIN_ATTEMPTS 5
         PASSWORD_LIFE_TIME UNLIMITED
         PASSWORD_REUSE_TIME 180
         PASSWORD_REUSE_MAX 1
         PASSWORD_VERIFY_FUNCTION "ORA12C_VERIFY_FUNCTION"
/

--revoke execute on UTL_TCP from PUBLIC;
--revoke execute on UTL_SMTP from PUBLIC;
---revoke execute on UTL_HTTP from PUBLIC;
--revoke execute on UTL_FILE from PUBLIC;
revoke execute on UTL_FILE from ORACLE_OCM;

